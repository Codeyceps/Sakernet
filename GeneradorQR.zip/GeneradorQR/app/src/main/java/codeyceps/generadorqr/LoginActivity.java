package codeyceps.generadorqr;

import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    private String [] numControl = {"16130795","16130787","16130835","16130801"};
    private String contrasena = "admin";

    EditText edTxtNoCtrl;
    EditText edTxtContra;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void btnEntrar(){
        edTxtNoCtrl = ( EditText ) findViewById ( R.id.edTxtControl );
        edTxtContra = ( EditText ) findViewById ( R.id.edTxtContrasena );

        if( validacion( edTxtNoCtrl.getText().toString(), edTxtContra.getText().toString()) )
            setContentView(R.layout.activity_main);
        else{
            AlertDialog.Builder dialogo = new AlertDialog.Builder(this);
            dialogo.setMessage("Información De Usuario Incorrecto")
                    .create()
                    .show();
        }
    }

    public boolean validacion (String ctrl, String contra ) {
        boolean valido = false;
        for(int i = 0; i<numControl.length; i++){
            if(ctrl == numControl[i] && contra == contrasena)
                valido = true;
        }
        return valido;
    }
}
